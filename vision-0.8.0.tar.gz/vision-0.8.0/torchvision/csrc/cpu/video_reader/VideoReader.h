#pragma once

#include <torch/script.h>

#pragma once

// Comment
#include <torch/script.h>
#include <torch/torch.h>
#include "read_image_cpu.h"
#include "read_write_file_cpu.h"
#include "readjpeg_cpu.h"
#include "readpng_cpu.h"
#include "writejpeg_cpu.h"
#include "writepng_cpu.h"

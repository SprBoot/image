# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# DiT: https://github.com/facebookresearch/DiT
# GLIDE: https://github.com/openai/glide-text2im
# MAE: https://github.com/facebookresearch/mae/blob/main/models_mae.py
# --------------------------------------------------------
from collections import OrderedDict

import torch
import torch.nn as nn

from models.rdt.blocks import (FinalLayer, RDTBlock, TimestepEmbedder,
                               get_1d_sincos_pos_embed_from_grid,
                               get_multimodal_cond_pos_embed)


class RDT(nn.Module):
    """
    Class for Robotics Diffusion Transformers.
    """
    def __init__(
        self,
        output_dim=128,
        horizon=32,
        hidden_size=1152,
        depth=28,
        num_heads=16,
        max_lang_cond_len=1024,
        img_cond_len=4096,
        lang_pos_embed_config=None,
        img_pos_embed_config=None,
        dtype=torch.bfloat16
    ):
        super().__init__()
        self.horizon = horizon
        self.hidden_size = hidden_size
        self.max_lang_cond_len = max_lang_cond_len
        self.img_cond_len = img_cond_len
        self.dtype = dtype
        self.lang_pos_embed_config = lang_pos_embed_config
        self.img_pos_embed_config = img_pos_embed_config
        #  初始化两个时间步嵌入器 (TimestepEmbedder)，用于处理时间步相关的特征。它们的隐藏层大小和数据类型由构造函数参数指定
        self.t_embedder = TimestepEmbedder(hidden_size, dtype=dtype)
        self.freq_embedder = TimestepEmbedder(hidden_size, dtype=dtype)
        
        # We will use trainable sin-cos embeddings
        # [timestep; state; action]
        # 创建一个可训练的正弦-余弦嵌入参数 x_pos_embed，用于表示时间步、状态和动作。它的形状为 (1, horizon + 3, hidden_size)，其中 horizon + 3 是为了额外包含时间步、状态和动作的嵌入
        self.x_pos_embed = nn.Parameter(
            torch.zeros(1, horizon+3, hidden_size))
        # 创建一个可训练的语言条件位置嵌入参数 lang_cond_pos_embed，用于表示每个语言条件的嵌入，形状为 (1, max_lang_cond_len, hidden_size)
        self.lang_cond_pos_embed = nn.Parameter(
            torch.zeros(1, max_lang_cond_len, hidden_size))
        # 创建一个可训练的图像条件位置嵌入参数 img_cond_pos_embed，用于表示每个图像条件的嵌入，形状为 (1, img_cond_len, hidden_size)
        self.img_cond_pos_embed = nn.Parameter(
            torch.zeros(1, img_cond_len, hidden_size))

        self.blocks = nn.ModuleList([
            RDTBlock(hidden_size, num_heads) for _ in range(depth)
        ])
        # 初始化一个 FinalLayer 实例，负责将模型的输出从隐藏层大小转换到指定的输出维度
        self.final_layer = FinalLayer(hidden_size, output_dim)
        self.initialize_weights()

    def initialize_weights(self):
        # Initialize transformer layers:
        def _basic_init(module):
            if isinstance(module, nn.Linear):
                # 使用 Xavier 均匀分布 初始化权重。
                # 如果线性层有偏置，则将偏置初始化为零。
                torch.nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
        # 使用 self.apply 方法遍历模型的所有子模块，并将 _basic_init 函数应用于每个模块，以初始化所有线性层的权重和偏置
        self.apply(_basic_init)

        # 使用 get_multimodal_cond_pos_embed 函数生成多模态条件位置嵌入。
        # 嵌入维度为 hidden_size。
        # 生成的嵌入包含时间步、控制频率、状态和动作的嵌入
        # 这里为论文中1 + 3 + 1 + 1
        x_pos_embed = get_multimodal_cond_pos_embed(
            embed_dim=self.hidden_size,
            mm_cond_lens=OrderedDict([
                ('timestep', 1),
                ('ctrl_freq', 1),
                ('state', 1),
                ('action', self.horizon),
            ])
        )
        self.x_pos_embed.data.copy_(torch.from_numpy(x_pos_embed).float().unsqueeze(0))
        # 如果没有提供语言位置嵌入配置，则使用正弦-余弦嵌入生成语言条件嵌入。
        # 如果提供了配置，则使用 get_multimodal_cond_pos_embed 生成相应的嵌入
        if self.lang_pos_embed_config is None:
            lang_cond_pos_embed = get_1d_sincos_pos_embed_from_grid(
                self.hidden_size, torch.arange(self.max_lang_cond_len))
        else:
            lang_cond_pos_embed = get_multimodal_cond_pos_embed(
                embed_dim=self.hidden_size,
                mm_cond_lens=OrderedDict(self.lang_pos_embed_config),
                embed_modality=False
            )
        self.lang_cond_pos_embed.data.copy_(
            torch.from_numpy(lang_cond_pos_embed).float().unsqueeze(0))
        # 如果没有提供图像位置嵌入配置，则使用正弦-余弦嵌入生成图像条件嵌入。
        # 如果提供了配置，则使用 get_multimodal_cond_pos_embed 生成相应的嵌入
        if self.img_pos_embed_config is None:
            img_cond_pos_embed = get_1d_sincos_pos_embed_from_grid(
                self.hidden_size, torch.arange(self.img_cond_len))
        else:
            img_cond_pos_embed = get_multimodal_cond_pos_embed(
                embed_dim=self.hidden_size,
                mm_cond_lens=OrderedDict(self.img_pos_embed_config),
                embed_modality=False
            )
        self.img_cond_pos_embed.data.copy_(
            torch.from_numpy(img_cond_pos_embed).float().unsqueeze(0))

        # 对时间步嵌入器和控制频率嵌入器的 MLP（多层感知器）中的特定层进行正态分布初始化，标准差为 0.02
        nn.init.normal_(self.t_embedder.mlp[0].weight, std=0.02)
        nn.init.normal_(self.t_embedder.mlp[2].weight, std=0.02)
        nn.init.normal_(self.freq_embedder.mlp[0].weight, std=0.02)
        nn.init.normal_(self.freq_embedder.mlp[2].weight, std=0.02)
            
        # 将最终线性层的权重和偏置初始化为零
        nn.init.constant_(self.final_layer.ffn_final.fc2.weight, 0)
        nn.init.constant_(self.final_layer.ffn_final.fc2.bias, 0)
        
        # Move all the params to given data type:
        self.to(self.dtype)

    def forward(self, x, freq, t, lang_c, img_c, lang_mask=None, img_mask=None):
        """
        Forward pass of RDT.
        # 状态和动作的序列，形状为 (B, T, D)，其中 T 为时间步数（horizon + 1），D 为隐藏层大小
        x: (B, T, D), state + action token sequence, T = horizon + 1,
            dimension D is assumed to be the same as the hidden size.
        # 控制频率的标量，形状为 (B,)
        freq: (B,), a scalar indicating control frequency.
        # 扩散时间步，形状为 (B,) 或 (1,)
        t: (B,) or (1,), diffusion timesteps.
        # 语言条件的标记序列，形状为 (B, L_lang, D) 或 None
        lang_c: (B, L_lang, D) or None, language condition tokens (variable length),
            dimension D is assumed to be the same as the hidden size.
        # 图像条件的标记序列，形状为 (B, L_img, D) 或 None
        img_c: (B, L_img, D) or None, image condition tokens (fixed length),
            dimension D is assumed to be the same as the hidden size.
        # 掩码是为了降低视觉或语言模块的权重，防止模型产生依赖行为
        # 语言条件的掩码，形状为 (B, L_lang) 或 None
        lang_mask: (B, L_lang) or None, language condition mask (True for valid).
        #  图像条件的掩码，形状为 (B, L_img) 或 None
        img_mask: (B, L_img) or None, image condition mask (True for valid).
        """
        # 使用时间步嵌入器 (t_embedder) 将 t 转换为嵌入，增加维度，使其形状为 (B, 1, D) 或 (1, 1, D)
        t = self.t_embedder(t).unsqueeze(1)             # (B, 1, D) or (1, 1, D)
        # 使用频率嵌入器 (freq_embedder) 将 freq 转换为嵌入，形状为 (B, 1, D)
        freq = self.freq_embedder(freq).unsqueeze(1)    # (B, 1, D)
        # Append timestep to the input tokens
        if t.shape[0] == 1:
            t = t.expand(x.shape[0], -1, -1)
        # 将时间步嵌入 t、频率嵌入 freq 和状态动作序列 x 沿第一个维度拼接，形成新的输入张量 x，形状为 (B, T+1, D)
        x = torch.cat([t, freq, x], dim=1)               # (B, T+1, D)
        
        # 将多模态位置嵌入 x_pos_embed 加到输入 x 上，以引入位置信息
        x = x + self.x_pos_embed
        # 对于语言条件 lang_c，将其与相应的语言位置嵌入相加，确保只使用有效的嵌入部分
        lang_c = lang_c + self.lang_cond_pos_embed[:, :lang_c.shape[1]]
        # 对于图像条件 img_c，将其与图像位置嵌入相加
        img_c = img_c + self.img_cond_pos_embed

        # Forward pass
        conds = [lang_c, img_c]
        masks = [lang_mask, img_mask]
        # 使用循环遍历 blocks 中的每个块（RDTBlock），交替使用语言条件和图像条件进行前向传播，更新输入 x
        for i, block in enumerate(self.blocks):
            c, mask = conds[i%2], masks[i%2]
            x = block(x, c, mask)                       # (B, T+1, D)
        # Inject the language condition at the final layer
        # 将经过所有 RDT 块处理后的 x 传递到最终层 final_layer，输出形状为 (B, T+1, out_channels)
        x = self.final_layer(x)                         # (B, T+1, out_channels)

        # 从输出中仅保留最后 horizon 个时间步的动作标记
        x = x[:, -self.horizon:]
        return x

cd ../datasets/aloha/

unzip aloha_mobile.zip
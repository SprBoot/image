# author:dinggc
# date:2022/3/18 下午12:41
import math
import numpy as np
from gaussian_shaped_labels import gaussian_shaped_labels
import cv2
from get_subwindow import get_subwindow
from get_features import get_features,hann
from gaussian_correlation import gaussian_correlation
import scipy
model_xf = []
model_alphaf = []
def tracker(video_path,img_files,pos,target_sz,padding,kernel,lambd,out_sigma_factor,interp_factor,cell_size,features,show_visualization):
    resize_image = math.sqrt(target_sz[0] * target_sz[1])
    if resize_image > 100:
        pos[0] = math.floor(int(pos[0]) / 2)
        pos[1] = math.floor(int(pos[1]) / 2)
        target_sz[0] = math.floor(int(target_sz[0]) / 2)
        target_sz[1] = math.floor(int(target_sz[0]) / 2)
    window_sz = []
    window_sz.append(math.floor(target_sz[0] * (1 + padding)))
    window_sz.append(math.floor(target_sz[1] * (1 + padding)))
    out_sigma = math.sqrt(target_sz[0] * target_sz[1]) * out_sigma_factor / cell_size
    yf = gaussian_shaped_labels(out_sigma,[math.floor(window_sz[0] / cell_size),math.floor(window_sz[1] / cell_size)])
    cos_window = hann(len(yf) - 1, len(yf[0]) - 1)
    positions = np.zeros((len(img_files),2))
    for frame in range(1,len(img_files)):
        print(frame)
        im = cv2.imread(video_path + img_files[frame-1][0])
        if len(im.shape) > 2:
            im = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
        if resize_image > 100:
            im = cv2.resize(im,0.5)
        if frame > 1:
            patch = get_subwindow(im,pos,window_sz)
            zf = get_features(patch,cell_size,cos_window)
            kzf = gaussian_correlation(zf,model_xf,kernel.sigma)
            response = np.real(scipy.fft.ifft2(model_alphaf * kzf))
            max = np.max(list(np.array(response).flatten()))
            [vert_delta,horiz_delta] = [0,0]
            out = False
            for i in range(len(response)):
                for j in range(len(response[0])):
                    if response[i][j] == max:
                        [vert_delta, horiz_delta] = [i, j]
                        out = True
                        break
                if out:
                    break
            if vert_delta > len(zf) / 2:
                vert_delta = vert_delta - len(zf)
            if horiz_delta > len(zf[0]) / 2:
                horiz_delta = horiz_delta - len(zf[0])
            pos = [vert_delta * cell_size + pos[0],horiz_delta * cell_size + pos[1]]
        patch = get_subwindow(im, pos, window_sz)
        xf = get_features(patch, cell_size, cos_window)
        kf = gaussian_correlation(xf, xf, kernel.sigma)
        alphaf = np.divide(yf,(kf + lambd))
        if frame == 1:
            model_alphaf = alphaf
            model_xf = xf
        else:
            model_alphaf = (1 - interp_factor) * model_alphaf + interp_factor * alphaf
            model_xf = (1 - interp_factor) * model_xf + interp_factor * xf
        positions[frame - 1] = pos
    return positions

def strArrayToInt(arr):
    result = []
    for i in arr:
        i = int(i)
        result.append(i)
    return result
def strArrayToFloat(arr):
    result = []
    for i in arr:
        i = float(i)
        result.append(i)
    return result
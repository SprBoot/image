# author:dinggc
# date:2022/3/18 上午11:05
# 输入视频所在路径和视频
# 返回参数为视频每帧的图片，初始位置，目标尺寸，真实标签和视频路径
import math
import os

def load_video_info(base_path, video):
    groundtruth = []
    for line in open(base_path + video + '/groundtruth_rect.txt'):
      groundtruth.append(line.replace('\n','').split(','))
    target_size = []
    target_size.append(groundtruth[0][3])
    target_size.append(groundtruth[0][2])
    pos = []
    pos.append(str(int(groundtruth[0][1]) +  math.floor(int(target_size[0]) / 2)))
    pos.append(str(int(groundtruth[0][0]) +  math.floor(int(target_size[1]) / 2)))
    if len(groundtruth) == 1:
        groundtruth = []
    else:
        gt = groundtruth
        groundtruth = []
        for i in gt:
            temp = []
            temp.append(str(float(i[1]) +  float(i[3]) / 2))
            temp.append(str(float(i[0]) + float(i[2]) / 2))
            groundtruth.append(temp)
    video_path = base_path + video + '/img/'
    img_files = []
    file_list = os.listdir(video_path)
    file_list.sort()
    for filename in file_list:
        fileinfo = os.stat(video_path + filename)
        img_file = []
        img_file.append(filename)
        img_file.append(base_path + video + '/img/')
        img_file.append(fileinfo.st_mtime)
        img_file.append(fileinfo.st_size)
        img_file.append(0)
        img_file.append(fileinfo.st_ctime)
        img_files.append(img_file)
    return img_files,pos,target_size,groundtruth,video_path
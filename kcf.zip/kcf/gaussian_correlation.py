# author:dinggc
# date:2022/3/18 下午3:37
import numpy as np
import scipy
import math

def gaussian_correlation(xf,yf,sigma):
    N = len(xf) * len(xf[0])
    xx = np.dot(np.array(list(np.array(xf).flatten())).T,np.array(list(np.array(xf).flatten()))) / N
    yy = np.dot(np.array(list(np.array(yf).flatten())).T,np.array(list(np.array(yf).flatten()))) / N
    xyf = xf * np.conj(xf)
    xy = np.sum(np.real(scipy.fft.ifft2(xyf)),axis=2)
    kf = scipy.fft.fft2(np.exp(-1 / math.pow(sigma,2) * np.maximum(0, (xx + yy - 2 * xy) / (len(xf) * len(xf[0])))))
    return kf
# author:dinggc
# date:2022/3/18 下午2:57
import numpy as np
import scipy
import fhog


def get_features(im,cell_size,cos_window):
    x = FHOG(im / 255,cell_size)
    x = np.delete(x,31,axis=2)
    x = addHann(x,cos_window)
    return scipy.fft.fft2(x)
def hann(M,N):
    hann2t, hann1t = np.ogrid[0:M + 1, 0:N + 1]
    hann1t = 0.5 - (0.5 * np.cos(2 * np.pi * hann1t / N))
    hann2t = 0.5 - (0.5 * np.cos(2 * np.pi * hann2t / M))
    hann2d = hann2t * hann1t
    return np.conj(hann2d)
def FHOG(img, binSize, nOrients=9, clip=.2, softBin=-1, useHog=2):
    h, w = img.shape[:2]
    M = np.zeros((h, w), dtype='float32')
    O = np.zeros((h, w), dtype='float32')
    H = np.zeros([img.shape[0] // binSize, img.shape[1] // binSize, 32], dtype='float32')
    fhog.gradientMag(img.astype(np.float32), M, O, 0, 1)
    fhog.gradientHist(M, O, H, binSize, nOrients, softBin, useHog, clip)
    return H
def addHann(x,window):
    window = np.expand_dims(window, 2)
    window = np.repeat(window, 31, 2)
    return x * window



# author:dinggc
# date:2022/3/18 下午2:16
import math


def get_subwindow(im,pos,sz):
    if len(sz) == 1:
        sz.append(sz)
    xs = []
    for i in range(1 + math.floor(pos[1]) - math.floor(sz[1] / 2),sz[1] + math.floor(pos[1]) - math.floor(sz[1] / 2) + 1):
        if i < 1:
            i = 1
        if i > im.shape[1]:
            i = im.shape[1]
        xs.append(i)
    ys = []
    for i in range(1 + math.floor(pos[0]) - math.floor(sz[0] / 2),sz[0] + math.floor(pos[0]) - math.floor(sz[0] / 2) + 1):
        if i < 1:
            i = 1
        if i > im.shape[0]:
            i = im.shape[0]
        ys.append(i)
    out = im[ys[0] - 1:ys[len(ys)-1],xs[0] - 1:xs[len(xs)-1]]
    return out
# author:dinggc
# date:2022/3/18 下午12:49
class Kernel():
    def __init__(self,type,sigma,poly_a,poly_b):
        self.type = type
        self.sigma = sigma
        self.poly_a = poly_a
        self.poly_b = poly_b

# author:dinggc
# date:2022/3/18 下午12:37
from  load_video_info import load_video_info
from tracker import tracker,strArrayToFloat,strArrayToInt
from kernel import Kernel
from features import Features
kernel = Kernel('gaussian',0.5,1,9)
features = Features(0,1,9)
img_files,pos,target_sz,ground_truth,video_path = load_video_info('/Users/dinggongcheng/Downloads/kcf/','Bolt')
target_sz = strArrayToInt(target_sz)
pos = strArrayToInt(pos)
positions = tracker(video_path,img_files,pos,target_sz,padding=1.5,kernel=kernel,lambd=1e-4,out_sigma_factor=0.1,interp_factor=0.02,cell_size=4,features=features,show_visualization=True)
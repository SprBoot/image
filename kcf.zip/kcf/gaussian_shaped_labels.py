# author:dinggc
# date:2022/3/18 下午1:13
import numpy as np
import math
import scipy
def gaussian_shaped_labels(sigma,sz):
    rs, cs = np.ogrid[1 - math.floor(sz[0] / 2):sz[0] - math.floor(sz[0]  / 2) + 1, 1 - math.floor(sz[1] / 2):sz[1] - math.floor(sz[1] / 2) + 1]
    labels = np.exp(-0.5 / math.pow(sigma,2) * (rs ** 2 + cs ** 2))
    labels = circshift(labels,-math.floor(sz[0] / 2) + 1,-math.floor(sz[1] / 2) + 1)
    labels = scipy.fft.fft2(labels)
    return labels
def circshift(u,shiftnum1,shiftnum2):
    h,w = u.shape
    if shiftnum1 < 0:
        u = np.vstack((u[-shiftnum1:,:],u[:-shiftnum1,:]))
    else:
        u = np.vstack((u[(h-shiftnum1):,:],u[:(h-shiftnum1),:]))
    if shiftnum2 > 0:
        u = np.hstack((u[:, (w - shiftnum2):], u[:, :(w - shiftnum2)]))
    else:
        u = np.hstack((u[:,-shiftnum2:],u[:,:-shiftnum2]))
    return u
# author:dinggc
# date:2022/3/18 下午12:52
class Features():
    def __init__(self,gray,hog,hog_orientations):
        self.gray = gray
        self.hog = hog
        self.hog_orientations = hog_orientations
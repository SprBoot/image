import numpy as np
import scipy
import fhog


def get_features(im,cell_size,cos_window):
    M = np.zeros(im.shape[:2], dtype='float32')
    O = np.zeros(im.shape[:2], dtype='float32')
    H = np.zeros([round(im.shape[0]/cell_size),round(im.shape[1]/cell_size), 32], dtype='float32') # python3
    x = fHOG(im / 255,M,O,H)
    x = np.delete(x,31,axis=2)
    x = addHann(x,cos_window)
    return scipy.fft.fft(x)
def hann(M,N):
    hann2t, hann1t = np.ogrid[0:M + 1, 0:N + 1]
    hann1t = 0.5 - (0.5 * np.cos(2 * np.pi * hann1t / N))
    hann2t = 0.5 - (0.5 * np.cos(2 * np.pi * hann2t / M))
    hann2d = hann2t * hann1t
    return np.conj(hann2d)
def fHOG(im_patch,M,O,H):
    fhog.gradientMag(im_patch.astype(np.float32),M,O)
    fhog.gradientHist(M,O,H)
    return H
def addHann(x,window):
    window = np.expand_dims(window, 2)
    window = np.repeat(window, 31, 2)
    return x * window

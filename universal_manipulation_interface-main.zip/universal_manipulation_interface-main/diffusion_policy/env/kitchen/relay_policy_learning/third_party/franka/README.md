# franka
Franka panda mujoco models


# Environment

franka_panda.xml           |  coming soon
:-------------------------:|:-------------------------:
![Alt text](franka_panda.png?raw=false "sawyer") |  coming soon

import pandas as pd
import os
import shutil

# 定义读取 Excel 文件并移动文件夹的函数
def process_excel_and_move_folders(excel_file, folder_path, target_directory):
    # 读取 Excel 文件
    df = pd.read_excel(excel_file)

    # 假设 Excel 文件中只有一列，且列名为 'name'
    if 'name' not in df.columns:
        print("Excel 文件中没有名为 'name' 的列")
        return

    # 遍历每一行，并以逗号分割获取名称
    for index, row in df.iterrows():
        names = row['name'].split(',')
        for name in names:
            name = name.strip()  # 去掉空格
            source_folder = os.path.join(folder_path, name)
            if os.path.exists(source_folder) and os.path.isdir(source_folder):
                # 移动文件夹到目标目录
                destination_folder = os.path.join(target_directory, name)
                print(f"移动文件夹: {source_folder} 到 {destination_folder}")
                shutil.move(source_folder, destination_folder)  # 移动目录到新位置
            else:
                print(f"文件夹不存在: {source_folder}")

# 定义主函数
if __name__ == "__main__":
    excel_file = './name.xlsx'  # 替换为你的 Excel 文件路径
    folder_path = '/home/gongcheng/Downloads/example_demo_session/demos'  # 替换为你的文件夹路径
    target_directory = '/home/gongcheng/Downloads/sure'  # 目标文件夹路径

    # 确保目标文件夹存在
    os.makedirs(target_directory, exist_ok=True)

    process_excel_and_move_folders(excel_file, folder_path, target_directory)
from typing import Dict, Callable, Tuple, List
import numpy as np
import collections
from diffusion_policy.common.cv2_util import get_image_transform
from diffusion_policy.common.pose_repr_util import (
    compute_relative_pose, 
    convert_pose_mat_rep
)
from umi.common.pose_util import (
    pose_to_mat, mat_to_pose, 
    mat_to_pose10d, pose10d_to_mat)
from diffusion_policy.model.common.rotation_transformer import \
    RotationTransformer

def get_real_obs_resolution(
        shape_meta: dict
        ) -> Tuple[int, int]:
    out_res = None
    obs_shape_meta = shape_meta['obs']
    for key, attr in obs_shape_meta.items():
        type = attr.get('type', 'low_dim')
        shape = attr.get('shape')
        if type == 'rgb':
            co,ho,wo = shape
            if out_res is None:
                out_res = (wo, ho)
            assert out_res == (wo, ho)
    return out_res


def get_real_obs_dict(
        env_obs: Dict[str, np.ndarray], 
        shape_meta: dict,
        ) -> Dict[str, np.ndarray]:
    obs_dict_np = dict()
    obs_shape_meta = shape_meta['obs']
    for key, attr in obs_shape_meta.items():
        type = attr.get('type', 'low_dim')
        shape = attr.get('shape')
        if type == 'rgb':
            this_imgs_in = env_obs[key]
            t,hi,wi,ci = this_imgs_in.shape
            co,ho,wo = shape
            assert ci == co
            out_imgs = this_imgs_in
            if (ho != hi) or (wo != wi) or (this_imgs_in.dtype == np.uint8):
                tf = get_image_transform(
                    input_res=(wi,hi), 
                    output_res=(wo,ho), 
                    bgr_to_rgb=False)
                out_imgs = np.stack([tf(x) for x in this_imgs_in])
                if this_imgs_in.dtype == np.uint8:
                    out_imgs = out_imgs.astype(np.float32) / 255
            # THWC to TCHW
            obs_dict_np[key] = np.moveaxis(out_imgs,-1,1)
        elif type == 'low_dim':
            this_data_in = env_obs[key]
            obs_dict_np[key] = this_data_in
    return obs_dict_np


def get_real_umi_obs_dict(
        # 一个字典，包含环境的观察数据，通常是来自机器人或传感器的原始信息
        env_obs: Dict[str, np.ndarray],
        # 描述观察数据形状和类型的元信息字典，例如，哪些数据是 RGB 图像，哪些是低维数据
        shape_meta: dict,
        # 字符串，指定观察姿态的表示方式（例如 'abs' 表示绝对位置，或 'relative' 表示相对位置）
        obs_pose_repr: str='abs',
        # 一个变换矩阵，用于确定机器人之间的相对位置和姿态，通常是从机器人 0 到机器人 1 的变换
        tx_robot1_robot0: np.ndarray=None,
        # 包含每个机器人的起始姿态的列表，用于计算相对姿态
        episode_start_pose: List[np.ndarray]=None,
        ) -> Dict[str, np.ndarray]:
    # 创建一个空字典 obs_dict_np 用于存储处理后的观察结果
    obs_dict_np = dict()
    # 获取观察数据的形状元信息，并初始化一个默认字典 robot_prefix_map 用于存储机器人相关的键
    obs_shape_meta = shape_meta['obs']
    #     camera0_rgb:
    #       shape: [3, 224, 224]
    #       horizon: ${task.img_obs_horizon} # int
    #       latency_steps: 0 # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # int
    #       type: rgb
    #       ignore_by_policy: False
    #     robot0_eef_pos:
    #       shape: [3]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.robot_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       ignore_by_policy: ${task.ignore_proprioception}
    #     robot0_eef_rot_axis_angle:
    #       raw_shape: [3]
    #       shape: [6]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.robot_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       rotation_rep: rotation_6d
    #       ignore_by_policy: ${task.ignore_proprioception}
    #     robot0_gripper_width:
    #       shape: [1]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.gripper_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       ignore_by_policy: ${task.ignore_proprioception}
    #     camera1_rgb:
    #       shape: [3, 224, 224]
    #       horizon: ${task.img_obs_horizon} # int
    #       latency_steps: 0 # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # int
    #       type: rgb
    #       ignore_by_policy: False
    #     robot1_eef_pos:
    #       shape: [3]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.robot_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       ignore_by_policy: ${task.ignore_proprioception}
    #     robot1_eef_rot_axis_angle:
    #       raw_shape: [3]
    #       shape: [6]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.robot_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       rotation_rep: rotation_6d
    #       ignore_by_policy: ${task.ignore_proprioception}
    #     robot1_gripper_width:
    #       shape: [1]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.gripper_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       ignore_by_policy: ${task.ignore_proprioception}
    #
    #     robot0_eef_pos_wrt1:
    #       shape: [3]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.robot_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       ignore_by_policy: ${task.ignore_proprioception}
    #     robot0_eef_rot_axis_angle_wrt1:
    #       raw_shape: [3]
    #       shape: [6]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.robot_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       ignore_by_policy: ${task.ignore_proprioception}
    #     robot1_eef_pos_wrt0:
    #       shape: [3]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.robot_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       ignore_by_policy: ${task.ignore_proprioception}
    #     robot1_eef_rot_axis_angle_wrt0:
    #       raw_shape: [3]
    #       shape: [6]
    #       horizon: ${task.low_dim_obs_horizon} # int
    #       latency_steps: ${eval:'(${task.camera_obs_latency} - ${task.robot_obs_latency}) * ${task.dataset_frequeny}'} # float
    #       down_sample_steps: ${task.obs_down_sample_steps} # float
    #       type: low_dim
    #       ignore_by_policy: ${task.ignore_proprioception}
    robot_prefix_map = collections.defaultdict(list)
    # 这里对定义的obs观测中的所有key进行遍历并封装数据
    # 具体需要封装的数据格式如下：
    # camera0_rgb,camera1_rgb 相机RGB图像
    # robot0_eef_pos, robot1_eef_pos 机器人末端位置，数据格式为x y z
    # robot0_eef_rot_axis_angle,robot1_eef_rot_axis_angle 机器人末端6D位姿
    # robot0_gripper_width,robot1_gripper_width 机器人夹爪宽度值
    # robot0_eef_pos_wrt1 机器人0相对于机器人1的末端位置
    # robot1_eef_pos_wrt0 机器人1相对于机器人0的末端位置
    # robot0_eef_rot_axis_angle_wrt1 机器人0相对于机器人1的末端位姿
    # robot1_eef_rot_axis_angle_wrt0 机器人1相对于机器人0的末端位姿
    for key, attr in obs_shape_meta.items():
        # 迭代每一个观察数据元信息，检查其类型和形状，根据不同类型（rgb图像和低维数据）进行处理
        type = attr.get('type', 'low_dim')
        shape = attr.get('shape')
        # 如果观察数据是 RGB 类型，进行图像的转换，包括改变图像大小和格式，并将结果存储在字典中
        # 观测数据包括RGB图像
        if type == 'rgb':
            this_imgs_in = env_obs[key]
            t,hi,wi,ci = this_imgs_in.shape
            co,ho,wo = shape
            assert ci == co
            out_imgs = this_imgs_in
            if (ho != hi) or (wo != wi) or (this_imgs_in.dtype == np.uint8):
                tf = get_image_transform(
                    input_res=(wi,hi), 
                    output_res=(wo,ho), 
                    bgr_to_rgb=False)
                out_imgs = np.stack([tf(x) for x in this_imgs_in])
                if this_imgs_in.dtype == np.uint8:
                    out_imgs = out_imgs.astype(np.float32) / 255
            # THWC to TCHW
            obs_dict_np[key] = np.moveaxis(out_imgs,-1,1)
        # 对于低维数据类型，直接将其存储在字典中。这里还避免了处理与末端执行器（eef）相关的数据
        # 观测数据包括shape mate中与排除eef的相关地位项目
        elif type == 'low_dim' and ('eef' not in key):
            this_data_in = env_obs[key]
            obs_dict_np[key] = this_data_in
            # handle multi-robots
            ks = key.split('_')
            if ks[0].startswith('robot'):
                robot_prefix_map[ks[0]].append(key)

    # 遍历每个机器人的前缀，拼接其末端执行器的位置和姿态，并转换为 4x4 位姿矩阵
    for robot_prefix in robot_prefix_map.keys():
        # convert pose to mat
        # 这里的_eef_rot_axis_angle为obs中获取到机器人的ActualTCPPose
        # 观测数据包括执行期末端的位置和角度
        pose_mat = pose_to_mat(np.concatenate([
            env_obs[robot_prefix + '_eef_pos'],
            env_obs[robot_prefix + '_eef_rot_axis_angle']
        ], axis=-1))

        # 使用提供的 base_pose_mat 和 obs_pose_repr 将位姿转换为所需的表示形式，并生成相应的观察
        # obs_pose_repr为相对位置
        obs_pose_mat = convert_pose_mat_rep(
            pose_mat, 
            base_pose_mat=pose_mat[-1],
            pose_rep=obs_pose_repr,
            backward=False)

        obs_pose = mat_to_pose10d(obs_pose_mat)
        obs_dict_np[robot_prefix + '_eef_pos'] = obs_pose[...,:3]
        obs_dict_np[robot_prefix + '_eef_rot_axis_angle'] = obs_pose[...,3:]
    
    # 遍历所有机器人，计算每个机器人的末端执行器相对于其他机器人的姿态。使用先前定义的变换矩阵 tx_robot1_robot0 来转换坐标
    n_robots = len(robot_prefix_map)
    for robot_id in range(n_robots):
        # convert pose to mat
        assert f'robot{robot_id}' in robot_prefix_map
        # 获取当前索引机器人的末端位置和姿态
        tx_robota_tcpa = pose_to_mat(np.concatenate([
            env_obs[f'robot{robot_id}_eef_pos'],
            env_obs[f'robot{robot_id}_eef_rot_axis_angle']
        ], axis=-1))
        # 对其他的机器人进行遍历
        for other_robot_id in range(n_robots):
            if robot_id == other_robot_id:
                continue
            # 获取其他机器人的位置和姿态
            tx_robotb_tcpb = pose_to_mat(np.concatenate([
                env_obs[f'robot{other_robot_id}_eef_pos'],
                env_obs[f'robot{other_robot_id}_eef_rot_axis_angle']
            ], axis=-1))
            # 在当前索引机器人坐标系下，其他机器人的位置和姿态
            tx_robota_robotb = tx_robot1_robot0
            # 若id为1，取逆
            if robot_id == 0:
                tx_robota_robotb = np.linalg.inv(tx_robot1_robot0)
            # 计算当前臂相对于其他臂的转移矩阵
            tx_robota_tcpb = tx_robota_robotb @ tx_robotb_tcpb

            rel_obs_pose_mat = convert_pose_mat_rep(
                tx_robota_tcpa,
                base_pose_mat=tx_robota_tcpb[-1],
                pose_rep='relative',
                backward=False)
            rel_obs_pose = mat_to_pose10d(rel_obs_pose_mat)
            # 这里存储的是当前id机器人与其他id机器人的转换关系
            obs_dict_np[f'robot{robot_id}_eef_pos_wrt{other_robot_id}'] = rel_obs_pose[:,:3]
            obs_dict_np[f'robot{robot_id}_eef_rot_axis_angle_wrt{other_robot_id}'] = rel_obs_pose[:,3:]

    # 如果起始姿态已经提供，计算机器人当前位姿相对于起始位姿的相对位姿，并将其存储。
    if episode_start_pose is not None:
        for robot_id in range(n_robots):        
            # convert pose to mat
            pose_mat = pose_to_mat(np.concatenate([
                env_obs[f'robot{robot_id}_eef_pos'],
                env_obs[f'robot{robot_id}_eef_rot_axis_angle']
            ], axis=-1))
            
            # get start pose
            start_pose = episode_start_pose[robot_id]
            start_pose_mat = pose_to_mat(start_pose)
            rel_obs_pose_mat = convert_pose_mat_rep(
                pose_mat,
                base_pose_mat=start_pose_mat,
                pose_rep='relative',
                backward=False)
            
            rel_obs_pose = mat_to_pose10d(rel_obs_pose_mat)
            # obs_dict_np[f'robot{robot_id}_eef_pos_wrt_start'] = rel_obs_pose[:,:3]
            # 这里存储的是当前机器人位姿相对起始位姿的关系
            obs_dict_np[f'robot{robot_id}_eef_rot_axis_angle_wrt_start'] = rel_obs_pose[:,3:]

    return obs_dict_np

def get_real_umi_action(
        action: np.ndarray,
        env_obs: Dict[str, np.ndarray], 
        action_pose_repr: str='abs'
    ):
    # action为九维的姿态和一维的夹爪
    n_robots = int(action.shape[-1] // 10)
    env_action = list()
    for robot_idx in range(n_robots):
        # 最新的末端执行期的位姿
        pose_mat = pose_to_mat(np.concatenate([
            env_obs[f'robot{robot_idx}_eef_pos'][-1],
            env_obs[f'robot{robot_idx}_eef_rot_axis_angle'][-1]
        ], axis=-1))

        start = robot_idx * 10
        action_pose10d = action[..., start:start+9]
        action_grip = action[..., start+9:start+10]
        # 将九维的姿态转换为矩阵
        action_pose_mat = pose10d_to_mat(action_pose10d)

        # 转换为相对与末端的位姿
        action_mat = convert_pose_mat_rep(
            action_pose_mat, 
            base_pose_mat=pose_mat,
            pose_rep=action_pose_repr,
            backward=True)

        # 矩阵转换为姿态
        action_pose = mat_to_pose(action_mat)
        env_action.append(action_pose)
        env_action.append(action_grip)

    env_action = np.concatenate(env_action, axis=-1)
    return env_action

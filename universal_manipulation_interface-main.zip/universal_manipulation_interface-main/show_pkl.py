# show_pkl.py
import pandas as pd
import pickle

path = './dataset_plan.pkl'  # path='/root/……/aus_openface.pkl'   pkl文件所在路径

f = open(path, 'rb')
data = pickle.load(f)
data_ = {'name': []}
print(len(data))
for i in data:
    camera = i['cameras']
    name_ = camera[0]['video_path'].split('/')[0]
    name = camera[1]['video_path'].split('/')[0]
    data_['name'].append(name_ + ',' + name)
df = pd.DataFrame(data_)
# 写入 Excel 文件
df.to_excel('name.xlsx', index=False)
